---
title: "Emacs Lsp Mode配置"
date: 2021-06-30T14:27:53+08:00
draft: false
---

## go language server(gopls)

```shell
go env -w GOPROXY=https://goproxy.io,direct 
go get golang.org/x/tools/gopls@latest
```


## python language server

```shell
sudo pip3 install python-language-server
```

## C/C++

```shell
sudo apt install clangd clang
```



